<?php

$con = mysqli_connect("localhost", "root", "", "login") or die("Couldn't connect");

?>